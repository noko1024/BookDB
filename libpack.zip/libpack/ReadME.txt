pathlib
pygame
requests